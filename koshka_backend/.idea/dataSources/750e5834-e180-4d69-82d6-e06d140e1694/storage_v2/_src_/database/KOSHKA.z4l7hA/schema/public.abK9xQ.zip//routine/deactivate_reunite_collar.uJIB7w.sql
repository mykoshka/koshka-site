create function deactivate_reunite_collar() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE reunite_collars SET active = FALSE WHERE tag_id IN (SELECT tag_id FROM pet_collars WHERE pet_id = OLD.id);
    RETURN OLD;
END;
$$;

alter function deactivate_reunite_collar() owner to "KOSHKA";

