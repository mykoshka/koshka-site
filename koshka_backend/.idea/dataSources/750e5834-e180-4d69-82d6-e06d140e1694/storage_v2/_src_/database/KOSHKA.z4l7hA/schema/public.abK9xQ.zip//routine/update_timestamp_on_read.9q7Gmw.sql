create function update_timestamp_on_read() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$;

alter function update_timestamp_on_read() owner to "KOSHKA";

